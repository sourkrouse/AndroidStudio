package com.zybooks.sensormanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor sensor;
    private Sensor mLight;

    public TextView mTextAccelReadout;
    public TextView mTextLightReadout;


    @Override
    public final void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        //sensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        sensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mLight = mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        mTextAccelReadout = (TextView) findViewById(R.id.textAccelReadout);
        mTextLightReadout = (TextView) findViewById(R.id.textLightReadout);


        sendtoConsoleSensor();



    }

    public void sendtoConsoleSensor(){
        //write all sensor code here(excluding sensor stopping method)
        Log.d("ACCELEROMETERSENSOR",sensor.toString());
        Log.d("LIGHTSENSOR",mLight.toString());


    }
    public void buttonClickReadout(View view) {
        SendReadout();
    }

    public void SendReadout(){
        //set value of text field to sensor manager info

        mTextAccelReadout.setText(sensor.toString());
        mTextLightReadout.setText(mLight.toString());

    }
    @Override
    public final void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Do something here if sensor accuracy changes.
    }

    @Override
    public final void onSensorChanged(SensorEvent event) {
        // The light sensor returns a single value.
        // Many sensors return 3 values, one for each axis.
        synchronized (this) {
            float lux = event.values[0];
            // Do something with this sensor value.
            mTextLightReadout.setText(String.valueOf(lux));


        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mLight, SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }





}